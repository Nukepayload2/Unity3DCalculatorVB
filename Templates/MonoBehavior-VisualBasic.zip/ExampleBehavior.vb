﻿Imports UnityEngine

Public Class $safeitemname$
    Inherits MonoBehaviour

    Private Sub Start()
        Debug.Log($"提示：游戏对象 {gameObject.name} 是用 Visual Basic 2017 写的！")
    End Sub

End Class
